#include <Arduino.h>
#include <Wire.h>
#include <vl53l4cx_class.h>

// ── Sensor pins ────────────────────────────────────────────────────────────
#define SDA_PIN   21
#define SCL_PIN   22
#define XSHUT_PIN  4

// ── Team 305 bus config ────────────────────────────────────────────────────
#define BUS_BAUD   9600      // team-agreed baud rate
#define PKT_LEN    64

// Frame markers
#define PRE1  0xA5
#define PRE2  0x5A
#define SUF1  0x59
#define SUF2  0x42

// Node IDs
#define MY_ID      0x4D   // Myles / distance
#define HMI_ID     0x43   // Christo
#define LIAM_ID    0x4C
#define ISAIAH_ID  0x49
#define ARIANNA_ID 0x41
#define RAGUL_ID   0x52
#define DAMIAN_ID  0x44
#define BCAST      0x58

// Message types
#define MSG_DIST  0x0C
#define MSG_REQ   0x14
#define MSG_ACK   0xAA

// Reserved bytes that must be stuffed in payload (positions 4-61)
static const uint8_t RESERVED[] = {PRE1, PRE2, SUF1, SUF2};

// All valid IDs on the bus
static const uint8_t KNOWN_IDS[] = {
  HMI_ID, LIAM_ID, ISAIAH_ID, ARIANNA_ID,
  MY_ID, RAGUL_ID, DAMIAN_ID, BCAST
};

// ── Globals ────────────────────────────────────────────────────────────────
VL53L4CX sensor(&Wire, XSHUT_PIN);
volatile int32_t g_distance_mm = -1;  // -1 = no valid reading

// ── Protocol helpers ───────────────────────────────────────────────────────
static bool isKnownId(uint8_t id) {
  for (uint8_t k : KNOWN_IDS) if (k == id) return true;
  return false;
}

static bool isReserved(uint8_t b) {
  for (uint8_t r : RESERVED) if (r == b) return true;
  return false;
}

// Build a 64-byte stuffed packet. Returns false if invalid.
static bool buildPacket(uint8_t receiver, uint8_t msgType,
                         const uint8_t* payload, uint8_t payLen,
                         uint8_t out[PKT_LEN]) {
  memset(out, 0, PKT_LEN);
  out[0] = PRE1;
  out[1] = PRE2;
  out[2] = MY_ID;
  out[3] = receiver;
  out[4] = msgType;

  for (uint8_t i = 0; i < payLen && (5 + i) < 62; i++)
    out[5 + i] = payload[i];

  // Byte stuffing: reserved values in positions 4-61 become (val-1)
  for (int i = 4; i < 62; i++)
    if (isReserved(out[i])) out[i] = (out[i] - 1) & 0xFF;

  out[62] = SUF1;
  out[63] = SUF2;
  return true;
}

static void sendPacket(uint8_t receiver, uint8_t msgType,
                       const uint8_t* payload, uint8_t payLen) {
  uint8_t pkt[PKT_LEN];
  if (buildPacket(receiver, msgType, payload, payLen, pkt))
    Serial.write(pkt, PKT_LEN);
}

static void sendAck(uint8_t dest, uint8_t originalType) {
  if (originalType == MSG_ACK) return;  // never ACK an ACK
  uint8_t pay[1] = {originalType};
  sendPacket(dest, MSG_ACK, pay, 1);
}

static void sendDistance(uint8_t dest) {
  int32_t d = g_distance_mm;
  if (d < 0) d = 0;
  uint32_t mm = (uint32_t)d;
  uint8_t pay[4];
  // little-endian uint32 mm — HMI accepts this format
  pay[0] = (mm >>  0) & 0xFF;
  pay[1] = (mm >>  8) & 0xFF;
  pay[2] = (mm >> 16) & 0xFF;
  pay[3] = (mm >> 24) & 0xFF;
  sendPacket(dest, MSG_DIST, pay, 4);
}

// ── RX state machine ───────────────────────────────────────────────────────
static uint8_t  rxBuf[PKT_LEN];
static uint8_t  rxIdx   = 0;
static uint8_t  rxState = 0;  // 0=wait P1, 1=wait P2, 2=collect

static void handlePacket(const uint8_t* pkt) {
  uint8_t sender   = pkt[2];
  uint8_t receiver = pkt[3];
  uint8_t msgType  = pkt[4];
  const uint8_t* payload = pkt + 5;

  if (receiver == MY_ID) {
    // ── addressed to us ──────────────────────────────────────────
    if (msgType == MSG_REQ && payload[0] == MSG_DIST) {
      sendDistance(sender);
    }
    // ACK every non-ACK unicast
    sendAck(sender, msgType);

  } else if (receiver == BCAST) {
    // ── broadcast: handle locally then forward ────────────────────
    // (nothing to handle for broadcast currently, just forward)
    Serial.write(pkt, PKT_LEN);

  } else {
    // ── not for us: forward unchanged ────────────────────────────
    Serial.write(pkt, PKT_LEN);
  }
}

static bool validatePacket(const uint8_t* pkt) {
  if (pkt[0] != PRE1 || pkt[1] != PRE2) return false;
  if (pkt[62] != SUF1 || pkt[63] != SUF2) return false;
  uint8_t sender   = pkt[2];
  uint8_t receiver = pkt[3];
  if (sender == 0x00 || receiver == 0x00) return false;
  if (!isKnownId(sender))   return false;
  if (!isKnownId(receiver)) return false;
  if (sender == MY_ID)      return false;  // loopback — discard
  return true;
}

static void feedByte(uint8_t b) {
  switch (rxState) {
    case 0:  // wait for PRE1
      if (b == PRE1) rxState = 1;
      break;
    case 1:  // wait for PRE2
      if      (b == PRE2) { memset(rxBuf, 0, PKT_LEN); rxBuf[0] = PRE1; rxBuf[1] = PRE2; rxIdx = 2; rxState = 2; }
      else if (b == PRE1) { /* repeated PRE1, stay */ }
      else                { rxState = 0; }
      break;
    case 2:  // collect
      rxBuf[rxIdx++] = b;
      if (rxIdx == PKT_LEN) {
        rxState = 0; rxIdx = 0;
        if (validatePacket(rxBuf)) handlePacket(rxBuf);
      }
      break;
  }
}

// ── Sensor init ────────────────────────────────────────────────────────────
static void initSensor() {
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);
  sensor.begin();
  sensor.VL53L4CX_Off();
  delay(10);
  sensor.InitSensor(0x52);
  sensor.VL53L4CX_StartMeasurement();
}

static void updateSensor() {
  uint8_t ready = 0;
  sensor.VL53L4CX_GetMeasurementDataReady(&ready);
  if (!ready) return;

  VL53L4CX_MultiRangingData_t data;
  sensor.VL53L4CX_GetMultiRangingData(&data);

  int32_t best = -1;
  float bestSig = 0;
  for (int i = 0; i < data.NumberOfObjectsFound; i++) {
    VL53L4CX_TargetRangeData_t *r = &data.RangeData[i];
    float sig = (float)r->SignalRateRtnMegaCps / 65536.0f;
    if (r->RangeStatus == 0 && sig > bestSig) {
      best    = r->RangeMilliMeter;
      bestSig = sig;
    }
  }
  g_distance_mm = best;
  sensor.VL53L4CX_ClearInterruptAndStartMeasurement();
}

// ── Main ───────────────────────────────────────────────────────────────────
void setup() {
  // UART0 (GPIO1 TX, GPIO3 RX) is the team bus at 9600 baud
  Serial.begin(BUS_BAUD);
  initSensor();
}

void loop() {
  // Drain bus RX
  while (Serial.available()) feedByte(Serial.read());

  // Update sensor reading (non-blocking)
  updateSensor();
}
