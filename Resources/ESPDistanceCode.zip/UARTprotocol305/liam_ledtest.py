from machine import UART, Pin, PWM
import time

from team_config import BAUD_RATE, HMI_ID, LIAM_ID, MSG_MOTOR_SPEED, ACK_TYPE
from uart_protocol import build_ack, route_packet, UARTReceiver

# Liam's UART pins from the original bench test
uart = UART(1, baudrate=BAUD_RATE, tx=Pin(17), rx=Pin(16))
uart_rx = UARTReceiver()

# One LED, so speed is shown by blink rate and brightness together
led = PWM(Pin(21), freq=1000)
led.duty_u16(0)

motor_speed = 0
_blink_on = False
_last_toggle = time.ticks_ms()


def _signed_int8(value):
    if value > 127:
        return value - 256
    return value


def _clamp_speed(value):
    if value > 100:
        return 100
    if value < -100:
        return -100
    return value


def _blink_period_ms(speed):
    magnitude = abs(speed)
    if magnitude <= 0:
        return None
    return 1000 - ((magnitude * 900) // 100)


def _blink_duty(speed):
    magnitude = abs(speed)
    if magnitude <= 0:
        return 0
    return 12000 + ((magnitude * (65535 - 12000)) // 100)


def _set_led(on_now):
    duty = _blink_duty(motor_speed) if on_now and motor_speed != 0 else 0
    led.duty_u16(duty)


def _handle_msg(msg_type, payload, sender):
    global motor_speed

    if msg_type == MSG_MOTOR_SPEED:
        if sender == HMI_ID:
            requested = 0
            if payload:
                requested = _signed_int8(payload[0])
            motor_speed = _clamp_speed(requested)
            _set_led(False)
            direction = "FWD" if motor_speed >= 0 else "REV"
            print(
                "[CMD] {} -> {} speed={} dir={}".format(
                    "{:02X}".format(sender),
                    "{:02X}".format(LIAM_ID),
                    abs(motor_speed),
                    direction,
                )
            )
        else:
            print("[IGN] motor cmd from non-HMI sender=0x{:02X}".format(sender))
    elif msg_type == ACK_TYPE:
        print("[ACK RX] for type=0x{:02X}".format(payload[0] if payload else 0))
    else:
        print(
            "[NODE] type=0x{:02X} from=0x{:02X} ignored locally".format(
                msg_type, sender
            )
        )


def _send_ack(dest, msg_type):
    if msg_type == ACK_TYPE:
        return
    pkt = build_ack(dest, msg_type)
    if pkt:
        uart.write(pkt)
        print("[ACK TX] to=0x{:02X} for=0x{:02X}".format(dest, msg_type))


def _forward(pkt):
    uart.write(pkt)
    print("[FWD] {} -> {}".format("{:02X}".format(pkt[2]), "{:02X}".format(pkt[3])))


def _service_led():
    global _blink_on, _last_toggle

    now = time.ticks_ms()
    period = _blink_period_ms(motor_speed)
    if period is None:
        if _blink_on:
            _blink_on = False
            _set_led(False)
        return

    on_time = max(30, period // 2)
    off_time = max(30, period - on_time)
    wait_time = on_time if _blink_on else off_time

    if time.ticks_diff(now, _last_toggle) >= wait_time:
        _blink_on = not _blink_on
        _last_toggle = now
        _set_led(_blink_on)


print("Team 305 Liam LED node ready")
print("Waiting for HMI motor speed packets on UART1 @ {} baud".format(BAUD_RATE))

while True:
    for raw_pkt in uart_rx.feed(uart):
        print(
            "[RX] {} -> {} type=0x{:02X}".format(
                "{:02X}".format(raw_pkt[2]),
                "{:02X}".format(raw_pkt[3]),
                raw_pkt[4],
            )
        )
        route_packet(
            raw_pkt,
            handle_fn=_handle_msg,
            send_ack_fn=_send_ack,
            forward_fn=_forward,
        )

    _service_led()
    time.sleep_ms(5)
