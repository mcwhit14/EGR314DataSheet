# Team 305 UART protocol guide

This folder is a handoff package for Ragul's Claude Code session.

It includes:
- `christo_team_config.py`
- `christo_uart_protocol.py`
- `christo_main.py`
- `liam_team_config.py`
- `liam_uart_protocol.py`
- `liam_ledtest.py`
- `liam_main.py`

Use Christo's files as the main reference for the HMI side and Liam's files as the reference for a simple MicroPython node that still follows the same bus protocol.

## What the bus looks like

The Team 305 UART bus uses fixed-size 64 byte packets.

Byte layout:
- byte 0: start byte 1 = `0xA5`
- byte 1: start byte 2 = `0x5A`
- byte 2: sender node ID
- byte 3: receiver node ID
- byte 4: message type
- bytes 5 through 61: payload window, zero padded
- byte 62: stop byte 1 = `0x59`
- byte 63: stop byte 2 = `0x42`

Bus settings:
- baud rate: `9600`
- framing: `8N1`
- packet size: always exactly `64` bytes

## Team node IDs

These are the IDs in Christo's current HMI code.

- Christo / HMI: `0x43`
- Liam / motor: `0x4C`
- Isaiah / temperature: `0x49`
- Arianna / camera: `0x41`
- Myles / distance: `0x4D`
- Ragul / gyro: `0x52`
- Damian: `0x44`
- broadcast / everyone: `0x58`

## Packet rules

### 1. Fixed 64-byte frame
Every packet is exactly 64 bytes. Do not send variable-length frames.

### 2. Reserved bytes
The frame markers are reserved:
- `0xA5`
- `0x5A`
- `0x59`
- `0x42`

In the Python protocol layer, any reserved byte found in positions `4..61` gets stuffed by subtracting 1 before transmit. That is handled in `uart_protocol.py`.

### 3. Receiver state machine
The canonical receive flow in the Python nodes is:
- wait for `0xA5`
- then wait for `0x5A`
- then collect until 64 bytes total
- validate prefix, suffix, sender and receiver IDs
- route the packet

In the Python reference files, this logic lives in `UARTReceiver.feed()`.

## Routing behavior

This is the expected bus behavior implemented in the shared `route_packet()` function.

If `receiver == MY_ID`:
- handle locally
- send ACK
- do not forward

If `receiver == BCAST`:
- handle locally
- forward downstream

If `receiver` is another valid node:
- do not handle locally
- forward unchanged

If `sender == MY_ID` on receive:
- treat as loopback
- discard

That loopback discard is what stops a frame from circulating forever once it comes back around the chain.

## ACK behavior

ACK message type is `0xAA`.

ACK payload:
- payload byte 0 = the original message type being acknowledged

Normal rule:
- send an ACK for any non-ACK unicast addressed to your node
- do not ACK an ACK

## Message types currently in use

### `0x01` motor speed
Christo -> Liam

Payload:
- signed int8 speed, range `-100..100`
- negative means reverse
- zero means stop
- positive means forward

In the current HMI code, motor packets are only sent when the value changes.

### `0x04` multi-use data packet
Two different senders use type `0x04`, so the receiver must disambiguate by sender ID.

Ragul gyro format:
- payload bytes `0..5`
- `<hhh>` little-endian
- `gx`, `gy`, `gz` as signed 16-bit integers

Arianna camera format in Christo's current code:
- `data[1]` = camera state
- `data[6]` = camera error

### `0x08` temperature
Isaiah -> HMI or requested node

Payload:
- int16 little-endian
- temperature multiplied by 100
- example: `25.50 C` -> `2550`

### `0x0C` distance
Myles -> HMI or requested node

Christo's HMI currently accepts multiple distance payload formats and normalizes to centimeters:
- float meters in bytes `1..4`
- float meters in bytes `0..3`
- uint32 millimeters in bytes `0..3`
- uint16 millimeters in bytes `0..1`

### `0x14` request packet
Any node -> target node

Payload:
- payload byte 0 = the message type being requested

Example:
- HMI requests temperature by sending `0x14` with payload byte `0x08`

### `0xAA` ACK
Receiver -> sender

Payload:
- payload byte 0 = echoed original message type

## Christo HMI behavior right now

Relevant files:
- `christo_team_config.py`
- `christo_uart_protocol.py`
- `christo_main.py`

Important points:
- HMI requests sensor data only on page entry or explicit `SEL` re-request
- HMI no longer auto-requests every few seconds
- motor control is special and remains live command-based
- HMI sends motor command `0x01` only when the speed changes, including a zero-speed stop packet
- gyro subpages use single `SEL` to request fresh data and double `SEL` to back out

### HMI request map
Christo's current request mapping is:
- Values page requests temp, camera, distance and gyro once
- Temp page requests `0x08` from Isaiah
- Camera page requests `0x04` from Arianna
- Distance page requests `0x0C` from Myles
- Gyro page requests `0x04` from Ragul

## Liam node behavior right now

Relevant files:
- `liam_team_config.py`
- `liam_uart_protocol.py`
- `liam_ledtest.py`
- `liam_main.py`

This is a small MicroPython node used as a motor/LED bench test.

Important points:
- it uses the same Team 305 framing and routing layer
- it acts on motor command `0x01` only if the sender is HMI (`0x43`)
- it forwards packets for other valid nodes the same way as the shared protocol layer says
- it ACKs non-ACK packets addressed to itself
- its LED behavior is local only: blink rate and PWM brightness both scale with absolute motor speed

## What Ragul's node should do

For a clean integration, Ragul's node should follow the same pattern:

1. define IDs and frame constants in one config location
2. use the same 64-byte framing
3. implement the same RX state machine
4. validate sender and receiver IDs
5. drop loopback packets where sender equals your own node ID
6. route exactly like the shared Python `route_packet()` behavior
7. ACK non-ACK packets addressed to your node
8. for gyro data, use sender ID `0x52` and message type `0x04`
9. pack gyro payload as little-endian signed 16-bit values

Recommended gyro payload for Christo's current HMI parser:
- bytes `0..5` = `<hhh>`
- `gx`, `gy`, `gz`

## If Claude Code is generating Ragul's code

The fastest path is:
- mirror `christo_uart_protocol.py` routing and RX logic
- use the IDs from `christo_team_config.py`
- implement Ragul-specific local handling for `0x04`
- keep all bus-facing framing identical

## Practical notes

- If the physical chain is not closed, software cannot create a true loopback by itself
- The protocol still assumes ring-like behavior, because loopback discard is part of the design
- HMI is now request-driven for sensor pages, so sensor nodes should reply immediately when requested instead of periodically spamming the bus

## File usage hints

For protocol logic, start here:
- `christo_uart_protocol.py`
- `liam_uart_protocol.py`

For bus usage in the HMI, start here:
- `christo_main.py`

For a minimal node example, start here:
- `liam_ledtest.py`

## Bottom line

If Ragul matches the framing, IDs, RX state machine, routing rules and gyro payload shape in this package, his Claude Code session should be able to build a compatible gyro node without reverse-engineering the bus from scratch.
