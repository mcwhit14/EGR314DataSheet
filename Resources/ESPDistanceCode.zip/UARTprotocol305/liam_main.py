# main.py
# MicroPython entrypoint for Liam's Team 305 LED bench test

import ledtest
